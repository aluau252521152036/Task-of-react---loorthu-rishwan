# Rishwan task

## What this repository contains
- Minimal React + Vite skeleton (UI demo)
- `db.json` for json-server with products, categories
- Placeholder Firebase config file (replace with real config)

## How to run locally

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start json-server (data API):
   ```bash
   npm run json-server
   ```
   This serves `db.json` at http://localhost:4000

3. Start the frontend:
   ```bash
   npm run dev
   ```

4. Open the URL shown by Vite (usually http://localhost:5173)

## Notes / Next steps
- Integrate Firebase Authentication (Google Sign-In). On login, create or fetch user entry in `users` array in `db.json`.
- Implement AuthContext to persist user, wishlist, cart.
- Implement Checkout flow: select address, post to `/orders`, patch product stock, clear cart.
- Admin simulation: create a simple admin page to PATCH `/orders/:id` status (On Process → Shipped → Delivered).
- This is a starter skeleton for the interview task. Extend components, add routing, and secure backend in production.
