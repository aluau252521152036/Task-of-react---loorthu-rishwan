import React from 'react';

export default function ProductCard({ product }){
  return (
    <div className="card">
      <img src={product.image} alt={product.title} style={{width:'100%', height:140, objectFit:'cover', borderRadius:6}} />
      <h3>{product.title}</h3>
      <p>₹{product.price}</p>
      <p>{product.stock === 0 ? 'Out of stock' : `In stock: ${product.stock}`}</p>
      <div style={{display:'flex', gap:8, marginTop:8}}>
        <button disabled={product.stock===0}>Add to cart</button>
        <button disabled={product.stock===0}>Wishlist</button>
      </div>
    </div>
  )
}
