import React from 'react'
import ProductList from './pages/ProductList'

export default function App(){
  return (
    <div className="container">
      <h1>Rishwan task — Product Management Demo</h1>
      <ProductList />
    </div>
  )
}
