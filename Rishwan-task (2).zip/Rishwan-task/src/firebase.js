// Paste your Firebase config here (replace placeholders). This file is intentionally a placeholder.
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  appId: "YOUR_APP_ID"
};

// Instructed to use Firebase SDK in README; keep this file for developers to replace with real config.
