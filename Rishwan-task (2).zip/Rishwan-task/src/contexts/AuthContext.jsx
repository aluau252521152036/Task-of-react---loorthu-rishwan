import React, { createContext, useEffect, useState } from 'react';
import api from '../api/api';

export const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  // This demo doesn't include real Firebase auth wiring.
  // For the interview task, integrate Firebase and call create/get user on login.

  useEffect(()=>{}, []);

  return <AuthContext.Provider value={{ user, setUser }}>{children}</AuthContext.Provider>
}
