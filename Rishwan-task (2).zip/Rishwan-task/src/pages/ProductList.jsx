import React, { useEffect, useState } from 'react';
import api from '../api/api';
import ProductCard from '../components/ProductCard';

export default function ProductList(){
  const [products,setProducts] = useState([]);
  const [q,setQ] = useState('');
  const [sortBy,setSortBy] = useState('');

  useEffect(()=>{
    api.get('/products').then(r=>setProducts(r.data)).catch(e=>console.error(e));
  },[]);

  const filtered = products
    .filter(p => p.title.toLowerCase().includes(q.toLowerCase()))
    .sort((a,b)=>{
      if(sortBy==='price-asc') return a.price-b.price;
      if(sortBy==='price-desc') return b.price-a.price;
      if(sortBy==='name') return a.title.localeCompare(b.title);
      return 0;
    });

  return (
    <div>
      <div style={{display:'flex', gap:8, marginBottom:12}}>
        <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search products..." />
        <select value={sortBy} onChange={e=>setSortBy(e.target.value)}>
          <option value="">Sort</option>
          <option value="price-asc">Price: Low → High</option>
          <option value="price-desc">Price: High → Low</option>
          <option value="name">Name</option>
        </select>
      </div>

      <div className="grid">
        {filtered.map(p => <ProductCard key={p.id} product={p} />)}
      </div>
    </div>
  )
}
